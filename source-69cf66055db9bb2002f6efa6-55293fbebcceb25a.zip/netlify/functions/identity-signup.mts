import type { Handler, HandlerEvent } from '@netlify/functions'

const handler: Handler = async (event: HandlerEvent) => {
  const body = JSON.parse(event.body || '{}')
  const user = body.user || {}

  return {
    statusCode: 200,
    body: JSON.stringify({
      app_metadata: {
        ...user.app_metadata,
        roles: user.app_metadata?.roles?.includes('admin')
          ? user.app_metadata.roles
          : ['user'],
      },
    }),
  }
}

export { handler }
