import { getStore } from '@netlify/blobs'
import { getUser } from '@netlify/identity'
import type { Config } from '@netlify/functions'

export const config: Config = {
  path: '/api/donate',
}

interface Donation {
  id: string
  userId: string
  userEmail: string
  donorName: string
  amount: number
  message: string
  phone: string
  createdAt: string
  notified: boolean
}

export default async (req: Request) => {
  const user = await getUser()
  if (!user) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 })
  }

  // GET: fetch user's donations
  if (req.method === 'GET') {
    const store = getStore({ name: 'ganpati-donations', consistency: 'strong' })
    try {
      const { blobs } = await store.list({ prefix: `donation/` })
      const donations: Donation[] = []

      for (const blob of blobs) {
        const d = await store.get(blob.key, { type: 'json' }) as Donation | null
        if (d && d.userId === user.id) {
          donations.push(d)
        }
      }

      donations.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      return Response.json({ donations })
    } catch (err) {
      console.error('GET donations error:', err)
      return Response.json({ error: 'Failed to fetch donations' }, { status: 500 })
    }
  }

  // POST: create donation
  if (req.method === 'POST') {
    let body: any
    try {
      body = await req.json()
    } catch {
      return Response.json({ error: 'Invalid request body' }, { status: 400 })
    }

    const amount = Number(body.amount)
    if (!amount || amount <= 0) {
      return Response.json({ error: 'Invalid donation amount' }, { status: 400 })
    }

    const donation: Donation = {
      id: crypto.randomUUID(),
      userId: user.id,
      userEmail: user.email,
      donorName: body.donorName || user.user_metadata?.full_name || user.email,
      amount,
      message: (body.message || '').slice(0, 300),
      phone: body.phone || user.user_metadata?.phone || '',
      createdAt: new Date().toISOString(),
      notified: false,
    }

    const store = getStore({ name: 'ganpati-donations', consistency: 'strong' })

    try {
      await store.setJSON(`donation/${donation.id}`, donation)

      // Send receipt notifications (non-blocking)
      sendNotifications(donation).catch(console.error)

      // Mark as notified after sending
      setTimeout(async () => {
        try {
          const updated = { ...donation, notified: true }
          await store.setJSON(`donation/${donation.id}`, updated)
        } catch {}
      }, 5000)

      return Response.json({ donation }, { status: 201 })
    } catch (err) {
      console.error('POST donation error:', err)
      return Response.json({ error: 'Failed to save donation' }, { status: 500 })
    }
  }

  return Response.json({ error: 'Method not allowed' }, { status: 405 })
}

async function sendNotifications(donation: Donation) {
  await Promise.allSettled([
    sendEmail(donation),
    sendSMS(donation),
  ])
}

async function sendEmail(donation: Donation) {
  const smtpHost = Netlify.env.get('SMTP_HOST')
  const smtpUser = Netlify.env.get('SMTP_USER')
  const smtpPass = Netlify.env.get('SMTP_PASS')
  const smtpFrom = Netlify.env.get('SMTP_FROM') || smtpUser

  if (!smtpHost || !smtpUser || !smtpPass) {
    console.log('SMTP not configured — skipping email receipt')
    return
  }

  const { default: nodemailer } = await import('nodemailer')

  const transporter = nodemailer.createTransport({
    host: smtpHost,
    port: parseInt(Netlify.env.get('SMTP_PORT') || '587'),
    secure: Netlify.env.get('SMTP_SECURE') === 'true',
    auth: { user: smtpUser, pass: smtpPass },
  })

  const fmt = (n: number) =>
    new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)

  const date = new Date(donation.createdAt).toLocaleString('en-IN', {
    dateStyle: 'long',
    timeStyle: 'short',
  })

  const html = `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"/></head>
<body style="margin:0;padding:0;background:#1a0500;font-family:Arial,sans-serif;">
  <div style="max-width:560px;margin:24px auto;background:linear-gradient(135deg,#1a0500,#3d1000);border:1px solid rgba(255,215,0,0.3);border-radius:16px;overflow:hidden;">
    <!-- Header -->
    <div style="background:linear-gradient(135deg,#FF6B2B,#FFD700);padding:32px 24px;text-align:center;">
      <div style="font-size:3rem;margin-bottom:8px;">ॐ</div>
      <h1 style="color:#1a0500;margin:0;font-size:1.8rem;font-weight:800;">Jai Ganesh!</h1>
      <p style="color:rgba(26,5,0,0.75);margin:6px 0 0;font-size:1rem;">Donation Receipt — Ganpati Utsav</p>
    </div>
    <!-- Body -->
    <div style="padding:32px 24px;">
      <p style="color:#FFF8E7;font-size:1.05rem;line-height:1.6;margin-bottom:24px;">
        Dear <strong style="color:#FFD700;">${donation.donorName}</strong>,<br/>
        Thank you for your generous offering. May Lord Ganesha bless you with wisdom, prosperity, and the removal of all obstacles! 🙏
      </p>
      <!-- Receipt Box -->
      <div style="background:rgba(255,215,0,0.08);border:1px solid rgba(255,215,0,0.25);border-radius:12px;padding:20px;margin-bottom:24px;">
        <h2 style="color:#FFD700;margin:0 0 16px;font-size:1.1rem;">Donation Details</h2>
        <table style="width:100%;border-collapse:collapse;">
          ${[
            ['Receipt ID', `#${donation.id.slice(0, 8).toUpperCase()}`],
            ['Amount', fmt(donation.amount)],
            ['Donor', donation.donorName],
            ['Email', donation.userEmail],
            ['Date', date],
            ...(donation.message ? [['Dedication', donation.message]] : []),
          ].map(([label, val]) => `
          <tr>
            <td style="color:rgba(255,215,0,0.7);padding:6px 0;font-size:0.85rem;width:40%;">${label}</td>
            <td style="color:#FFF8E7;padding:6px 0;font-weight:600;font-size:0.95rem;">${val}</td>
          </tr>`).join('')}
        </table>
      </div>
      <p style="color:rgba(255,248,231,0.6);font-size:0.85rem;line-height:1.6;text-align:center;margin:0;">
        Ganpati Bappa Morya! 🐘<br/>
        This is an automated receipt. Please keep it for your records.
      </p>
    </div>
    <!-- Footer -->
    <div style="background:rgba(0,0,0,0.3);padding:16px 24px;text-align:center;border-top:1px solid rgba(255,215,0,0.15);">
      <div style="font-size:1.5rem;color:#FFD700;">ॐ</div>
      <p style="color:rgba(255,248,231,0.35);font-size:0.75rem;margin:4px 0 0;">Ganpati Utsav — Powered by Netlify</p>
    </div>
  </div>
</body>
</html>`

  await transporter.sendMail({
    from: `"Ganpati Utsav 🐘" <${smtpFrom}>`,
    to: donation.userEmail,
    subject: `🙏 Donation Receipt — ₹${donation.amount.toLocaleString('en-IN')} — Ganpati Bappa Morya!`,
    html,
  })

  console.log(`Email receipt sent to ${donation.userEmail}`)
}

async function sendSMS(donation: Donation) {
  if (!donation.phone) return

  const accountSid = Netlify.env.get('TWILIO_ACCOUNT_SID')
  const authToken = Netlify.env.get('TWILIO_AUTH_TOKEN')
  const fromPhone = Netlify.env.get('TWILIO_PHONE_NUMBER')

  if (!accountSid || !authToken || !fromPhone) {
    console.log('Twilio not configured — skipping SMS receipt')
    return
  }

  const url = `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`
  const auth = Buffer.from(`${accountSid}:${authToken}`).toString('base64')
  const fmt = (n: number) => `INR ${n.toLocaleString('en-IN')}`

  const body =
    `Om Ganeshaya Namah! 🐘\n` +
    `Receipt: #${donation.id.slice(0, 8).toUpperCase()}\n` +
    `Donor: ${donation.donorName}\n` +
    `Amount: ${fmt(donation.amount)}\n` +
    `Date: ${new Date(donation.createdAt).toLocaleDateString('en-IN')}\n` +
    `Ganpati Bappa Morya! Thank you for your generous donation.`

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Basic ${auth}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({ To: donation.phone, From: fromPhone, Body: body }),
  })

  if (!res.ok) {
    const err = await res.text()
    console.error('SMS send error:', err)
  } else {
    console.log(`SMS receipt sent to ${donation.phone}`)
  }
}
