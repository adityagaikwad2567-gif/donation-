import { getStore } from '@netlify/blobs'
import type { Config } from '@netlify/functions'

export const config: Config = {
  path: '/api/stats',
}

interface Donation {
  id: string
  userId: string
  amount: number
}

export default async (_req: Request) => {
  try {
    const store = getStore({ name: 'ganpati-donations' })
    const { blobs } = await store.list({ prefix: 'donation/' })

    let totalAmount = 0
    const donors = new Set<string>()

    for (const blob of blobs) {
      const d = await store.get(blob.key, { type: 'json' }) as Donation | null
      if (d) {
        totalAmount += d.amount
        donors.add(d.userId)
      }
    }

    return Response.json({
      totalAmount,
      totalDonations: blobs.length,
      totalDonors: donors.size,
    })
  } catch (err) {
    console.error('Stats error:', err)
    return Response.json({ totalAmount: 0, totalDonations: 0, totalDonors: 0 })
  }
}
