import { getStore } from '@netlify/blobs'
import { getUser } from '@netlify/identity'
import type { Config } from '@netlify/functions'

export const config: Config = {
  path: ['/api/admin/donations', '/api/admin/bulk-notify'],
}

interface Donation {
  id: string
  userId: string
  userEmail: string
  donorName: string
  amount: number
  message: string
  phone: string
  createdAt: string
  notified: boolean
}

export default async (req: Request, context: any) => {
  const user = await getUser()
  if (!user) {
    return Response.json({ error: 'Unauthorized' }, { status: 401 })
  }

  const roles: string[] = user.app_metadata?.roles ?? []
  if (!roles.includes('admin')) {
    return Response.json({ error: 'Forbidden — admin only' }, { status: 403 })
  }

  const url = new URL(req.url)

  // Bulk notify endpoint
  if (url.pathname.includes('bulk-notify') && req.method === 'POST') {
    const { message } = await req.json().catch(() => ({ message: '' }))
    if (!message?.trim()) {
      return Response.json({ error: 'Message is required' }, { status: 400 })
    }

    // Get all unique user emails
    const store = getStore({ name: 'ganpati-donations', consistency: 'strong' })
    const { blobs } = await store.list({ prefix: 'donation/' })
    const emails = new Set<string>()
    for (const blob of blobs) {
      const d = await store.get(blob.key, { type: 'json' }) as Donation | null
      if (d?.userEmail) emails.add(d.userEmail)
    }

    // Send bulk emails (if SMTP configured)
    await sendBulkEmails([...emails], message, user.email)

    return Response.json({
      message: `Notification queued for ${emails.size} devotee(s).`,
      count: emails.size,
    })
  }

  // GET /api/admin/donations
  if (req.method === 'GET') {
    const store = getStore({ name: 'ganpati-donations', consistency: 'strong' })
    const { blobs } = await store.list({ prefix: 'donation/' })

    const donations: Donation[] = []
    for (const blob of blobs) {
      const d = await store.get(blob.key, { type: 'json' }) as Donation | null
      if (d) donations.push(d)
    }

    donations.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

    const uniqueDonors = new Set(donations.map((d) => d.userId))
    const stats = {
      totalAmount: donations.reduce((s, d) => s + d.amount, 0),
      totalDonations: donations.length,
      totalDonors: uniqueDonors.size,
    }

    return Response.json({ donations, stats })
  }

  return Response.json({ error: 'Method not allowed' }, { status: 405 })
}

async function sendBulkEmails(emails: string[], message: string, adminEmail: string) {
  const smtpHost = Netlify.env.get('SMTP_HOST')
  const smtpUser = Netlify.env.get('SMTP_USER')
  const smtpPass = Netlify.env.get('SMTP_PASS')
  const smtpFrom = Netlify.env.get('SMTP_FROM') || smtpUser

  if (!smtpHost || !smtpUser || !smtpPass) {
    console.log('SMTP not configured — bulk email skipped')
    return
  }

  const { default: nodemailer } = await import('nodemailer')
  const transporter = nodemailer.createTransport({
    host: smtpHost,
    port: parseInt(Netlify.env.get('SMTP_PORT') || '587'),
    secure: Netlify.env.get('SMTP_SECURE') === 'true',
    auth: { user: smtpUser, pass: smtpPass },
  })

  const html = `
<!DOCTYPE html>
<html>
<body style="margin:0;padding:0;background:#1a0500;font-family:Arial,sans-serif;">
  <div style="max-width:560px;margin:24px auto;background:linear-gradient(135deg,#1a0500,#3d1000);border:1px solid rgba(255,215,0,0.3);border-radius:16px;overflow:hidden;">
    <div style="background:linear-gradient(135deg,#FF6B2B,#FFD700);padding:28px 24px;text-align:center;">
      <div style="font-size:2.5rem;">ॐ</div>
      <h1 style="color:#1a0500;margin:4px 0 0;font-size:1.5rem;">Ganpati Utsav Announcement</h1>
    </div>
    <div style="padding:28px 24px;">
      <p style="color:#FFF8E7;font-size:1rem;line-height:1.7;white-space:pre-wrap;">${message.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</p>
      <p style="color:rgba(255,248,231,0.5);font-size:0.85rem;margin-top:24px;text-align:center;">
        Ganpati Bappa Morya! 🐘 — Sent by your admin team
      </p>
    </div>
  </div>
</body>
</html>`

  for (const email of emails) {
    try {
      await transporter.sendMail({
        from: `"Ganpati Utsav 🐘" <${smtpFrom}>`,
        to: email,
        subject: '🙏 Ganpati Utsav — Important Announcement',
        html,
      })
    } catch (err) {
      console.error(`Failed to send bulk email to ${email}:`, err)
    }
  }
}
