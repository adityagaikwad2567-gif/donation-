import { getUser } from '@netlify/identity'

export async function authFetch(url: string, options: RequestInit = {}) {
  const user = await getUser()
  const token = (user as any)?.token?.access_token as string | undefined

  return fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers as Record<string, string> | undefined),
    },
  })
}
