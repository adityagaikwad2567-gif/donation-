interface GaneshaIconProps {
  size?: number
  className?: string
}

export function GaneshaIcon({ size = 120, className = '' }: GaneshaIconProps) {
  const h = size * 1.3
  return (
    <svg
      viewBox="0 0 200 260"
      width={size}
      height={h}
      className={className}
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Lord Ganesha"
    >
      {/* Crown / Mukut */}
      <polygon points="100,6 91,28 100,24 109,28" fill="#FFD700" />
      <polygon points="78,13 67,36 78,32 89,36" fill="#FF8C00" />
      <polygon points="122,13 133,36 122,32 111,36" fill="#FF8C00" />
      <polygon points="58,22 48,46 60,42 70,46" fill="#FFD700" />
      <polygon points="142,22 152,46 140,42 130,46" fill="#FFD700" />
      <rect x="46" y="44" width="108" height="12" rx="6" fill="#B8860B" />
      <rect x="50" y="46" width="100" height="8" rx="4" fill="#FFD700" />
      {/* Crown jewels */}
      <ellipse cx="100" cy="50" rx="8" ry="6" fill="#DC143C" />
      <ellipse cx="74" cy="50" rx="5" ry="4" fill="#9B59B6" />
      <ellipse cx="126" cy="50" rx="5" ry="4" fill="#27AE60" />

      {/* Left ear */}
      <ellipse cx="42" cy="122" rx="36" ry="55" fill="#B85520" />
      <ellipse cx="42" cy="122" rx="24" ry="40" fill="#F09060" />

      {/* Right ear */}
      <ellipse cx="158" cy="122" rx="36" ry="55" fill="#B85520" />
      <ellipse cx="158" cy="122" rx="24" ry="40" fill="#F09060" />

      {/* Head */}
      <ellipse cx="100" cy="110" rx="72" ry="76" fill="#A84820" />
      {/* Face */}
      <ellipse cx="100" cy="124" rx="57" ry="64" fill="#D07040" />

      {/* Tilak / Bindi */}
      <ellipse cx="100" cy="86" rx="6" ry="8" fill="#DC143C" />
      <ellipse cx="100" cy="83" rx="3" ry="4" fill="#FFD700" />

      {/* Left eye */}
      <ellipse cx="80" cy="110" rx="13" ry="15" fill="white" />
      <circle cx="82" cy="112" r="8" fill="#1a0a00" />
      <circle cx="85" cy="109" r="3.5" fill="white" />
      <path d="M 67 107 Q 80 100 93 107" fill="#A84820" />

      {/* Right eye */}
      <ellipse cx="120" cy="110" rx="13" ry="15" fill="white" />
      <circle cx="118" cy="112" r="8" fill="#1a0a00" />
      <circle cx="121" cy="109" r="3.5" fill="white" />
      <path d="M 107 107 Q 120 100 133 107" fill="#A84820" />

      {/* Trunk curling right (auspicious - Valampuri) */}
      <path
        d="M 117 150 Q 148 172 156 200 Q 162 220 147 223 Q 132 226 127 210"
        fill="none"
        stroke="#A84820"
        strokeWidth="20"
        strokeLinecap="round"
      />
      <path
        d="M 118 150 Q 149 172 157 200 Q 163 220 148 223"
        fill="none"
        stroke="#C86030"
        strokeWidth="12"
        strokeLinecap="round"
      />
      <ellipse cx="130" cy="214" rx="12" ry="10" fill="#A84820" />

      {/* Left tusk (full - auspicious) */}
      <path
        d="M 83 148 Q 50 168 42 196"
        fill="none"
        stroke="#FFFACD"
        strokeWidth="9"
        strokeLinecap="round"
      />

      {/* Right tusk (broken - Ekadanta symbolism) */}
      <path
        d="M 117 148 Q 150 165 154 182"
        fill="none"
        stroke="#FFFACD"
        strokeWidth="9"
        strokeLinecap="round"
      />
      <line x1="153" y1="182" x2="160" y2="190" stroke="#FFFACD" strokeWidth="6" strokeLinecap="round" />

      {/* Muzzle area */}
      <ellipse cx="100" cy="150" rx="24" ry="18" fill="#C06028" />

      {/* Body */}
      <ellipse cx="100" cy="232" rx="62" ry="52" fill="#B85520" />
      {/* Belly */}
      <ellipse cx="100" cy="240" rx="40" ry="34" fill="#CC7040" />
      {/* Navel */}
      <circle cx="100" cy="244" r="5" fill="#A84820" />
      <circle cx="100" cy="244" r="2.5" fill="#FF6B2B" />

      {/* Waist sash */}
      <path d="M 38 198 Q 100 208 162 198" fill="none" stroke="#FFD700" strokeWidth="7" />
      <path d="M 40 203 Q 100 213 160 203" fill="none" stroke="#FF8C00" strokeWidth="4" />

      {/* Upper left arm (holds lotus) */}
      <path
        d="M 52 206 Q 22 186 10 162"
        fill="none"
        stroke="#B85520"
        strokeWidth="22"
        strokeLinecap="round"
      />
      {/* Lotus */}
      <circle cx="11" cy="159" r="16" fill="#FF69B4" />
      <circle cx="11" cy="159" r="10" fill="#FF1493" />
      <circle cx="11" cy="159" r="5" fill="#FFD700" />
      <rect x="4" y="148" width="14" height="5" rx="2.5" fill="#FFD700" />

      {/* Upper right arm (holds axe) */}
      <path
        d="M 148 206 Q 178 186 190 162"
        fill="none"
        stroke="#B85520"
        strokeWidth="22"
        strokeLinecap="round"
      />
      <ellipse cx="190" cy="156" rx="12" ry="14" fill="#D07040" />
      <rect x="184" y="145" width="12" height="4" rx="2" fill="#FFD700" />

      {/* Lower left arm (holds modak) */}
      <path
        d="M 46 244 Q 16 254 8 272"
        fill="none"
        stroke="#B85520"
        strokeWidth="18"
        strokeLinecap="round"
      />
      {/* Modak */}
      <ellipse cx="9" cy="276" rx="13" ry="16" fill="#FFD700" />
      <path d="M -4 276 Q 9 264 22 276" fill="#FF8C00" />
      <ellipse cx="9" cy="263" rx="5" ry="4" fill="#FF6B2B" />

      {/* Lower right arm (blessing gesture) */}
      <path
        d="M 154 244 Q 184 254 192 272"
        fill="none"
        stroke="#B85520"
        strokeWidth="18"
        strokeLinecap="round"
      />
      <ellipse cx="192" cy="275" rx="11" ry="13" fill="#D07040" />
    </svg>
  )
}
