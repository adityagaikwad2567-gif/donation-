import {
  createContext,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react'

interface UserToken {
  access_token: string
  token_type: string
  expires_in: number
  refresh_token: string
  expires_at: number
}

export interface AuthUser {
  id: string
  email: string
  name?: string
  emailVerified: boolean
  app_metadata?: { roles?: string[]; provider?: string }
  user_metadata?: { full_name?: string; phone?: string; [key: string]: any }
  token?: UserToken
}

interface AuthContextValue {
  user: AuthUser | null
  loading: boolean
  login: (email: string, password: string) => Promise<AuthUser>
  signup: (
    email: string,
    password: string,
    name: string,
    phone?: string,
  ) => Promise<AuthUser>
  logout: () => Promise<void>
  isAdmin: boolean
}

const AuthContext = createContext<AuthContextValue | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let unsubscribe: (() => void) | undefined

    async function init() {
      try {
        const { getUser, onAuthChange, AUTH_EVENTS, handleAuthCallback } =
          await import('@netlify/identity')

        // Process any auth callback (email confirmation, password recovery, etc.)
        try {
          await handleAuthCallback()
        } catch {
          // Ignore callback errors on normal loads
        }

        const currentUser = await getUser()
        setUser(currentUser as AuthUser | null)
        setLoading(false)

        unsubscribe = onAuthChange((_event, u) => {
          setUser(u as AuthUser | null)
        })
      } catch {
        setLoading(false)
      }
    }

    init()

    return () => {
      unsubscribe?.()
    }
  }, [])

  async function login(email: string, password: string): Promise<AuthUser> {
    const { login: identityLogin } = await import('@netlify/identity')
    const u = await identityLogin(email, password)
    setUser(u as AuthUser)
    return u as AuthUser
  }

  async function signup(
    email: string,
    password: string,
    name: string,
    phone?: string,
  ): Promise<AuthUser> {
    const { signup: identitySignup } = await import('@netlify/identity')
    const u = await identitySignup(email, password, {
      full_name: name,
      phone: phone ?? '',
    })
    setUser(u as AuthUser)
    return u as AuthUser
  }

  async function logout(): Promise<void> {
    const { logout: identityLogout } = await import('@netlify/identity')
    await identityLogout()
    setUser(null)
  }

  const isAdmin = user?.app_metadata?.roles?.includes('admin') ?? false

  return (
    <AuthContext.Provider value={{ user, loading, login, signup, logout, isAdmin }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}
