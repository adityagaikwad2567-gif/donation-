import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { useState, useEffect } from 'react'
import { useAuth } from '../components/AuthContext'
import { authFetch } from '../lib/api'

export const Route = createFileRoute('/admin')({
  component: AdminPage,
})

interface Donation {
  id: string
  userId: string
  userEmail: string
  donorName: string
  amount: number
  message: string
  createdAt: string
  phone?: string
  notified?: boolean
}

interface AdminStats {
  totalAmount: number
  totalDonations: number
  totalDonors: number
}

function AdminPage() {
  const { user, loading, logout, isAdmin } = useAuth()
  const navigate = useNavigate()
  const [donations, setDonations] = useState<Donation[]>([])
  const [stats, setStats] = useState<AdminStats | null>(null)
  const [fetching, setFetching] = useState(true)
  const [error, setError] = useState('')
  const [bulkMsg, setBulkMsg] = useState('')
  const [sendingBulk, setSendingBulk] = useState(false)
  const [bulkResult, setBulkResult] = useState('')
  const [filterText, setFilterText] = useState('')
  const [page, setPage] = useState(0)
  const PAGE_SIZE = 20

  useEffect(() => {
    if (!loading && !user) navigate({ to: '/login' })
    if (!loading && user && !isAdmin) navigate({ to: '/' })
  }, [user, loading, isAdmin, navigate])

  useEffect(() => {
    if (!user || !isAdmin) return
    authFetch('/api/admin/donations')
      .then((r) => r.json())
      .then((data) => {
        setDonations(data.donations || [])
        setStats(data.stats || null)
      })
      .catch(() => setError('Failed to load admin data.'))
      .finally(() => setFetching(false))
  }, [user, isAdmin])

  if (loading) return <LoadingScreen />
  if (!user || !isAdmin) return null

  const fmt = (n: number) =>
    new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)

  const filtered = donations.filter(
    (d) =>
      !filterText ||
      d.donorName.toLowerCase().includes(filterText.toLowerCase()) ||
      d.userEmail.toLowerCase().includes(filterText.toLowerCase()) ||
      d.amount.toString().includes(filterText),
  )

  const paged = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE)
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE)

  async function sendBulkNotification() {
    if (!bulkMsg.trim()) return
    setSendingBulk(true)
    setBulkResult('')
    try {
      const res = await authFetch('/api/admin/bulk-notify', {
        method: 'POST',
        body: JSON.stringify({ message: bulkMsg }),
      })
      const data = await res.json()
      setBulkResult(data.message || 'Notifications sent!')
      setBulkMsg('')
    } catch {
      setBulkResult('Failed to send notifications.')
    } finally {
      setSendingBulk(false)
    }
  }

  return (
    <div className="ganpati-bg min-h-screen">
      {/* Navbar */}
      <nav style={{ background: 'rgba(26,5,0,0.9)', borderBottom: '1px solid rgba(255,215,0,0.25)', backdropFilter: 'blur(12px)', padding: '12px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Link to="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span className="gold-text" style={{ fontSize: '1.6rem' }}>ॐ</span>
          <span className="gold-text font-bold">Ganpati Utsav</span>
        </Link>
        <div className="flex items-center gap-3">
          <span style={{ background: 'rgba(255,107,43,0.25)', color: '#FF6B2B', padding: '4px 12px', borderRadius: '50px', fontSize: '0.8rem', border: '1px solid rgba(255,107,43,0.4)' }}>
            Admin
          </span>
          <button onClick={() => logout()} className="btn-outline-gold" style={{ padding: '8px 16px', fontSize: '0.85rem' }}>
            Logout
          </button>
        </div>
      </nav>

      <div className="max-w-6xl mx-auto px-4 py-10">
        {/* Header */}
        <div className="mb-8">
          <h1 className="gold-text font-bold" style={{ fontSize: '2rem', marginBottom: '6px' }}>
            🛕 Admin Dashboard
          </h1>
          <p style={{ color: 'rgba(255,248,231,0.55)' }}>
            Manage donations and send notifications • Logged in as {user.email}
          </p>
        </div>

        {error && <div className="alert-error mb-6">{error}</div>}

        {/* Stats */}
        {stats && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-10">
            {[
              { icon: '💰', label: 'Total Collected', value: fmt(stats.totalAmount), highlight: true },
              { icon: '🤲', label: 'Total Donations', value: stats.totalDonations.toLocaleString(), highlight: false },
              { icon: '🙏', label: 'Total Devotees', value: stats.totalDonors.toLocaleString(), highlight: false },
            ].map(({ icon, label, value, highlight }) => (
              <div key={label} className="stat-card" style={highlight ? { borderColor: 'rgba(255,215,0,0.4)', background: 'rgba(255,215,0,0.1)' } : {}}>
                <div style={{ fontSize: '2.5rem', marginBottom: '8px' }}>{icon}</div>
                <div className="gold-text font-bold" style={{ fontSize: '1.8rem' }}>{value}</div>
                <div style={{ color: 'rgba(255,248,231,0.6)', marginTop: '6px' }}>{label}</div>
              </div>
            ))}
          </div>
        )}

        {/* Bulk Notification */}
        <div className="card-ganesh-solid mb-8" style={{ padding: '24px' }}>
          <h2 className="gold-text font-bold mb-4" style={{ fontSize: '1.2rem' }}>
            📢 Send Bulk Notification
          </h2>
          <p style={{ color: 'rgba(255,248,231,0.55)', fontSize: '0.9rem', marginBottom: '16px' }}>
            Send an announcement email to all registered devotees.
          </p>
          <div className="flex flex-col gap-3">
            <textarea
              className="input-ganesh"
              style={{ minHeight: '80px', resize: 'vertical' }}
              placeholder="Type your message to all devotees..."
              value={bulkMsg}
              onChange={(e) => setBulkMsg(e.target.value)}
              maxLength={500}
            />
            <div className="flex items-center gap-3">
              <button
                onClick={sendBulkNotification}
                className="btn-gold"
                disabled={sendingBulk || !bulkMsg.trim()}
                style={{ padding: '10px 24px' }}
              >
                {sendingBulk ? 'Sending…' : '📨 Send to All'}
              </button>
              {bulkResult && (
                <span style={{ color: bulkResult.includes('Failed') ? '#fca5a5' : '#86efac', fontSize: '0.9rem' }}>
                  {bulkResult}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Donations Table */}
        <div className="card-ganesh-solid" style={{ padding: '24px', overflowX: 'auto' }}>
          <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
            <h2 className="gold-text font-bold" style={{ fontSize: '1.2rem' }}>
              All Donations ({filtered.length})
            </h2>
            <input
              type="text"
              className="input-ganesh"
              style={{ maxWidth: '240px', padding: '8px 14px', fontSize: '0.85rem' }}
              placeholder="🔍 Search by name / email / amount"
              value={filterText}
              onChange={(e) => { setFilterText(e.target.value); setPage(0) }}
            />
          </div>

          {fetching ? (
            <div className="text-center py-8" style={{ color: 'rgba(255,248,231,0.4)' }}>Loading…</div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-8" style={{ color: 'rgba(255,248,231,0.4)' }}>
              {donations.length === 0 ? 'No donations yet.' : 'No results match your search.'}
            </div>
          ) : (
            <>
              <table className="admin-table" style={{ minWidth: '700px' }}>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Donor</th>
                    <th>Email</th>
                    <th>Amount</th>
                    <th>Message</th>
                    <th>Date</th>
                    <th>Receipt</th>
                  </tr>
                </thead>
                <tbody>
                  {paged.map((d, idx) => (
                    <tr key={d.id}>
                      <td style={{ color: 'rgba(255,248,231,0.4)', fontSize: '0.8rem' }}>
                        {page * PAGE_SIZE + idx + 1}
                      </td>
                      <td style={{ fontWeight: 600 }}>{d.donorName}</td>
                      <td style={{ color: 'rgba(255,248,231,0.65)', fontSize: '0.85rem' }}>{d.userEmail}</td>
                      <td className="gold-text font-bold">{fmt(d.amount)}</td>
                      <td style={{ maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: 'rgba(255,248,231,0.65)', fontSize: '0.85rem', fontStyle: 'italic' }}>
                        {d.message || '—'}
                      </td>
                      <td style={{ fontSize: '0.8rem', color: 'rgba(255,248,231,0.55)', whiteSpace: 'nowrap' }}>
                        {new Date(d.createdAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                      </td>
                      <td>
                        <span style={{
                          background: d.notified ? 'rgba(34,197,94,0.15)' : 'rgba(255,248,231,0.05)',
                          color: d.notified ? '#86efac' : 'rgba(255,248,231,0.4)',
                          padding: '2px 10px',
                          borderRadius: '50px',
                          fontSize: '0.75rem',
                          border: `1px solid ${d.notified ? 'rgba(34,197,94,0.3)' : 'rgba(255,248,231,0.1)'}`,
                        }}>
                          {d.notified ? '✓ Sent' : 'Pending'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-3 mt-5">
                  <button
                    onClick={() => setPage((p) => Math.max(0, p - 1))}
                    disabled={page === 0}
                    className="btn-outline-gold"
                    style={{ padding: '6px 16px', fontSize: '0.85rem', opacity: page === 0 ? 0.4 : 1 }}
                  >
                    ← Prev
                  </button>
                  <span style={{ color: 'rgba(255,248,231,0.55)', fontSize: '0.85rem' }}>
                    Page {page + 1} / {totalPages}
                  </span>
                  <button
                    onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                    disabled={page >= totalPages - 1}
                    className="btn-outline-gold"
                    style={{ padding: '6px 16px', fontSize: '0.85rem', opacity: page >= totalPages - 1 ? 0.4 : 1 }}
                  >
                    Next →
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}

function LoadingScreen() {
  return (
    <div className="ganpati-bg min-h-screen flex items-center justify-center">
      <div className="gold-text text-center">
        <div className="om-glow" style={{ fontSize: '4rem', marginBottom: '16px' }}>ॐ</div>
        <p style={{ color: 'rgba(255,248,231,0.6)' }}>Loading admin panel…</p>
      </div>
    </div>
  )
}
