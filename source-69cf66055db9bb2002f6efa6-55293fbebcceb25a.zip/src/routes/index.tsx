import { createFileRoute, Link } from '@tanstack/react-router'
import { useState, useEffect } from 'react'
import { GaneshaIcon } from '../components/GaneshaIcon'
import { useAuth } from '../components/AuthContext'

export const Route = createFileRoute('/')({
  component: LandingPage,
})

interface Stats {
  totalAmount: number
  totalDonations: number
  totalDonors: number
}

function LandingPage() {
  const { user, logout, loading } = useAuth()
  const [stats, setStats] = useState<Stats | null>(null)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    fetch('/api/stats')
      .then((r) => r.json())
      .then((data: Stats) => setStats(data))
      .catch(() => {})
  }, [])

  const formatAmount = (n: number) =>
    new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)

  return (
    <div className="ganpati-bg min-h-screen">
      {/* Navbar */}
      <nav
        style={{
          background: 'rgba(26,5,0,0.85)',
          borderBottom: '1px solid rgba(255,215,0,0.2)',
          backdropFilter: 'blur(12px)',
          position: 'sticky',
          top: 0,
          zIndex: 50,
        }}
      >
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2" style={{ textDecoration: 'none' }}>
            <span style={{ fontSize: '1.8rem', lineHeight: 1 }} className="gold-text">ॐ</span>
            <span className="gold-text font-bold text-lg">Ganpati Utsav</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-2">
            <Link to="/" className="nav-link">Home</Link>
            {user && <Link to="/donate" className="nav-link">Donate</Link>}
            {user && <Link to="/dashboard" className="nav-link">My Donations</Link>}
            {user?.app_metadata?.roles?.includes('admin') && (
              <Link to="/admin" className="nav-link">Admin</Link>
            )}
            {!loading && !user ? (
              <>
                <Link to="/login"><button className="btn-outline-gold ml-2">Login</button></Link>
                <Link to="/register"><button className="btn-gold ml-2">Register</button></Link>
              </>
            ) : user ? (
              <button
                onClick={() => logout()}
                className="btn-outline-gold ml-2"
              >
                Logout
              </button>
            ) : null}
          </div>

          {/* Mobile hamburger */}
          <button
            className="md:hidden"
            style={{ color: '#FFD700', background: 'none', border: 'none', fontSize: '1.5rem', cursor: 'pointer' }}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? '✕' : '☰'}
          </button>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div
            style={{
              background: 'rgba(26,5,0,0.97)',
              borderTop: '1px solid rgba(255,215,0,0.15)',
              padding: '16px',
            }}
            className="flex flex-col gap-3 md:hidden"
          >
            <Link to="/" className="nav-link" onClick={() => setMenuOpen(false)}>Home</Link>
            {user && <Link to="/donate" className="nav-link" onClick={() => setMenuOpen(false)}>Donate</Link>}
            {user && <Link to="/dashboard" className="nav-link" onClick={() => setMenuOpen(false)}>My Donations</Link>}
            {user?.app_metadata?.roles?.includes('admin') && (
              <Link to="/admin" className="nav-link" onClick={() => setMenuOpen(false)}>Admin</Link>
            )}
            {!loading && !user ? (
              <div className="flex gap-2 mt-2">
                <Link to="/login" onClick={() => setMenuOpen(false)}><button className="btn-outline-gold">Login</button></Link>
                <Link to="/register" onClick={() => setMenuOpen(false)}><button className="btn-gold">Register</button></Link>
              </div>
            ) : user ? (
              <button onClick={() => { logout(); setMenuOpen(false) }} className="btn-outline-gold mt-2">
                Logout
              </button>
            ) : null}
          </div>
        )}
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden" style={{ padding: '60px 16px 80px' }}>
        {/* Decorative radial glow */}
        <div
          style={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '700px',
            height: '700px',
            background: 'radial-gradient(circle, rgba(255,107,43,0.15) 0%, rgba(255,215,0,0.08) 40%, transparent 70%)',
            pointerEvents: 'none',
          }}
        />

        <div className="max-w-4xl mx-auto text-center relative">
          {/* OM Symbol */}
          <div className="om-glow float-anim" style={{ fontSize: '6rem', lineHeight: 1, marginBottom: '16px', color: '#FFD700' }}>
            ॐ
          </div>

          {/* Ganesha SVG */}
          <div className="flex justify-center mb-6">
            <GaneshaIcon size={160} className="float-anim" style={{ animationDelay: '0.5s' } as React.CSSProperties} />
          </div>

          <h1 className="gold-text font-bold" style={{ fontSize: 'clamp(2.2rem, 6vw, 4rem)', marginBottom: '12px' }}>
            Jai Ganesh Deva!
          </h1>
          <h2 style={{ color: '#FF6B2B', fontSize: 'clamp(1.1rem, 3vw, 1.6rem)', marginBottom: '20px', fontWeight: 500 }}>
            Ganpati Utsav — Fund Collection & Donation Portal
          </h2>

          <p style={{ color: 'rgba(255,248,231,0.75)', maxWidth: '600px', margin: '0 auto 36px', lineHeight: 1.7, fontSize: '1.05rem' }}>
            Contribute to the grand Ganpati celebrations. Every donation brings blessings of Lord Ganesha — the remover of obstacles, bestower of wisdom and prosperity.
          </p>

          {/* Decorative lotus divider */}
          <div className="lotus-divider" style={{ maxWidth: '400px', margin: '0 auto 36px' }}>
            <span>✿</span>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-wrap gap-4 justify-center">
            {user ? (
              <>
                <Link to="/donate">
                  <button className="btn-gold" style={{ fontSize: '1.1rem', padding: '14px 36px' }}>
                    🙏 Donate Now
                  </button>
                </Link>
                <Link to="/dashboard">
                  <button className="btn-outline-gold" style={{ fontSize: '1.1rem', padding: '14px 36px' }}>
                    View My Donations
                  </button>
                </Link>
              </>
            ) : (
              <>
                <Link to="/register">
                  <button className="btn-gold" style={{ fontSize: '1.1rem', padding: '14px 36px' }}>
                    🙏 Join & Donate
                  </button>
                </Link>
                <Link to="/login">
                  <button className="btn-outline-gold" style={{ fontSize: '1.1rem', padding: '14px 36px' }}>
                    Sign In
                  </button>
                </Link>
              </>
            )}
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section style={{ background: 'rgba(255,215,0,0.06)', borderTop: '1px solid rgba(255,215,0,0.15)', borderBottom: '1px solid rgba(255,215,0,0.15)', padding: '40px 16px' }}>
        <div className="max-w-4xl mx-auto">
          <h3 className="text-center gold-text font-bold mb-8" style={{ fontSize: '1.4rem', letterSpacing: '0.05em' }}>
            ✦ COLLECTION HIGHLIGHTS ✦
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            <div className="stat-card">
              <div style={{ fontSize: '2.5rem', marginBottom: '8px' }}>💰</div>
              <div className="gold-text font-bold" style={{ fontSize: '1.8rem' }}>
                {stats ? formatAmount(stats.totalAmount) : '—'}
              </div>
              <div style={{ color: 'rgba(255,248,231,0.65)', marginTop: '6px' }}>Total Collected</div>
            </div>
            <div className="stat-card">
              <div style={{ fontSize: '2.5rem', marginBottom: '8px' }}>🤲</div>
              <div className="gold-text font-bold" style={{ fontSize: '1.8rem' }}>
                {stats ? stats.totalDonations.toLocaleString() : '—'}
              </div>
              <div style={{ color: 'rgba(255,248,231,0.65)', marginTop: '6px' }}>Donations Made</div>
            </div>
            <div className="stat-card">
              <div style={{ fontSize: '2.5rem', marginBottom: '8px' }}>🙏</div>
              <div className="gold-text font-bold" style={{ fontSize: '1.8rem' }}>
                {stats ? stats.totalDonors.toLocaleString() : '—'}
              </div>
              <div style={{ color: 'rgba(255,248,231,0.65)', marginTop: '6px' }}>Devotees</div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Cards */}
      <section style={{ padding: '60px 16px' }}>
        <div className="max-w-5xl mx-auto">
          <h3 className="text-center gold-text font-bold mb-10" style={{ fontSize: '1.6rem' }}>
            Ganesh's Blessings Await You
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                icon: '🎁',
                title: 'Easy Donations',
                desc: 'Contribute any amount to the celebrations. Support prasad, decorations, cultural programs and more.',
                color: '#FFD700',
              },
              {
                icon: '📨',
                title: 'Instant Receipts',
                desc: 'Receive email and SMS confirmations instantly after your donation. Your generosity is acknowledged.',
                color: '#FF6B2B',
              },
              {
                icon: '📊',
                title: 'Transparent Tracking',
                desc: 'View your complete donation history. Admins manage funds with full transparency.',
                color: '#DC143C',
              },
            ].map((f) => (
              <div key={f.title} className="card-ganesh p-6 text-center">
                <div style={{ fontSize: '3rem', marginBottom: '16px' }}>{f.icon}</div>
                <h4 style={{ color: f.color, fontWeight: 700, fontSize: '1.15rem', marginBottom: '10px' }}>{f.title}</h4>
                <p style={{ color: 'rgba(255,248,231,0.7)', lineHeight: 1.7, fontSize: '0.95rem' }}>{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Donation Amounts Quick Select */}
      <section
        style={{
          background: 'linear-gradient(135deg, rgba(255,107,43,0.1), rgba(255,215,0,0.06))',
          borderTop: '1px solid rgba(255,215,0,0.15)',
          padding: '50px 16px',
        }}
      >
        <div className="max-w-3xl mx-auto text-center">
          <div className="gold-text font-bold mb-3" style={{ fontSize: '1.4rem' }}>
            ✦ Popular Donation Amounts ✦
          </div>
          <p style={{ color: 'rgba(255,248,231,0.65)', marginBottom: '28px' }}>
            Every rupee counts towards a grand celebration
          </p>
          <div className="flex flex-wrap gap-3 justify-center mb-8">
            {[101, 251, 501, 1001, 2101, 5001].map((amt) => (
              <div key={amt} className="amount-chip">
                ₹{amt.toLocaleString('en-IN')}
              </div>
            ))}
          </div>
          <Link to={user ? '/donate' : '/register'}>
            <button className="btn-gold" style={{ fontSize: '1.1rem', padding: '14px 48px' }}>
              🙏 Make Your Offering
            </button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer
        style={{
          borderTop: '1px solid rgba(255,215,0,0.15)',
          padding: '32px 16px',
          textAlign: 'center',
          background: 'rgba(0,0,0,0.3)',
        }}
      >
        <div className="om-glow" style={{ fontSize: '2.5rem', marginBottom: '12px', color: '#FFD700' }}>
          ॐ
        </div>
        <p className="gold-text font-semibold mb-2">Ganpati Bappa Morya! 🐘</p>
        <p style={{ color: 'rgba(255,248,231,0.4)', fontSize: '0.85rem' }}>
          May Lord Ganesha bless all devotees with wisdom, prosperity and happiness.
        </p>
      </footer>
    </div>
  )
}
