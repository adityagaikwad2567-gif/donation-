import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { useState } from 'react'
import { useAuth } from '../components/AuthContext'
import { GaneshaIcon } from '../components/GaneshaIcon'

export const Route = createFileRoute('/register')({
  component: RegisterPage,
})

function RegisterPage() {
  const { signup, user } = useAuth()
  const navigate = useNavigate()
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [loading, setLoading] = useState(false)

  if (user) {
    navigate({ to: '/' })
    return null
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setSuccess('')

    if (password !== confirm) {
      setError('Passwords do not match.')
      return
    }
    if (password.length < 8) {
      setError('Password must be at least 8 characters.')
      return
    }

    setLoading(true)
    try {
      const u = await signup(email, password, name, phone)
      if (u.emailVerified) {
        navigate({ to: '/donate' })
      } else {
        setSuccess('Account created! Please check your email to confirm your account.')
      }
    } catch (err: any) {
      const status = err?.status
      if (status === 422) setError('Invalid email or password format.')
      else if (status === 403) setError('Registrations are currently closed. Contact the organizer.')
      else if (err?.message) setError(err.message)
      else setError('Registration failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div
      className="ganpati-bg min-h-screen flex flex-col items-center justify-center"
      style={{ padding: '24px 16px' }}
    >
      {/* Top nav */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '16px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Link to="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span className="gold-text" style={{ fontSize: '1.6rem' }}>ॐ</span>
          <span className="gold-text font-bold">Ganpati Utsav</span>
        </Link>
        <Link to="/login"><button className="btn-outline-gold" style={{ padding: '8px 20px', fontSize: '0.9rem' }}>Login</button></Link>
      </div>

      {/* Card */}
      <div className="mandala-border" style={{ width: '100%', maxWidth: '440px', padding: '40px 32px', marginTop: '60px' }}>
        <div className="text-center mb-8">
          <GaneshaIcon size={80} className="mx-auto mb-4" />
          <div className="om-glow gold-text" style={{ fontSize: '2rem', marginBottom: '8px' }}>ॐ</div>
          <h1 className="gold-text font-bold" style={{ fontSize: '1.8rem', marginBottom: '6px' }}>Join the Celebration</h1>
          <p style={{ color: 'rgba(255,248,231,0.6)', fontSize: '0.95rem' }}>
            Register to donate and receive blessings
          </p>
        </div>

        <div className="lotus-divider mb-6">
          <span style={{ color: '#FFD700' }}>✿</span>
        </div>

        {error && <div className="alert-error mb-4">{error}</div>}
        {success && <div className="alert-success mb-4">{success}</div>}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label style={{ color: '#FFD700', fontSize: '0.85rem', fontWeight: 600, display: 'block', marginBottom: '6px' }}>
              Full Name *
            </label>
            <input
              type="text"
              className="input-ganesh"
              placeholder="Your Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
            />
          </div>
          <div>
            <label style={{ color: '#FFD700', fontSize: '0.85rem', fontWeight: 600, display: 'block', marginBottom: '6px' }}>
              Email Address *
            </label>
            <input
              type="email"
              className="input-ganesh"
              placeholder="devotee@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
            />
          </div>
          <div>
            <label style={{ color: '#FFD700', fontSize: '0.85rem', fontWeight: 600, display: 'block', marginBottom: '6px' }}>
              Mobile Number <span style={{ color: 'rgba(255,248,231,0.4)' }}>(for SMS receipts)</span>
            </label>
            <input
              type="tel"
              className="input-ganesh"
              placeholder="+91 98765 43210"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          <div>
            <label style={{ color: '#FFD700', fontSize: '0.85rem', fontWeight: 600, display: 'block', marginBottom: '6px' }}>
              Password *
            </label>
            <input
              type="password"
              className="input-ganesh"
              placeholder="Min. 8 characters"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="new-password"
            />
          </div>
          <div>
            <label style={{ color: '#FFD700', fontSize: '0.85rem', fontWeight: 600, display: 'block', marginBottom: '6px' }}>
              Confirm Password *
            </label>
            <input
              type="password"
              className="input-ganesh"
              placeholder="••••••••"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              required
              autoComplete="new-password"
            />
          </div>

          <button
            type="submit"
            className="btn-gold w-full mt-2"
            style={{ padding: '14px', fontSize: '1rem' }}
            disabled={loading}
          >
            {loading ? 'Creating account…' : '🙏 Create Account'}
          </button>
        </form>

        <div className="lotus-divider mt-6 mb-4">
          <span style={{ color: 'rgba(255,215,0,0.5)', fontSize: '0.85rem' }}>Already registered?</span>
        </div>

        <Link to="/login" style={{ textDecoration: 'none', display: 'block', textAlign: 'center' }}>
          <button className="btn-saffron w-full" style={{ padding: '12px', fontSize: '0.95rem' }}>
            Sign In
          </button>
        </Link>
      </div>

      <p style={{ color: 'rgba(255,248,231,0.3)', fontSize: '0.8rem', marginTop: '24px' }}>
        Ganpati Bappa Morya 🐘
      </p>
    </div>
  )
}
