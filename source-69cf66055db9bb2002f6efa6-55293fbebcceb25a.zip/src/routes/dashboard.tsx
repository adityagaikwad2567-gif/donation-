import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { useState, useEffect } from 'react'
import { useAuth } from '../components/AuthContext'
import { authFetch } from '../lib/api'

export const Route = createFileRoute('/dashboard')({
  component: DashboardPage,
})

interface Donation {
  id: string
  amount: number
  donorName: string
  message: string
  createdAt: string
  phone?: string
}

function DashboardPage() {
  const { user, loading, logout } = useAuth()
  const navigate = useNavigate()
  const [donations, setDonations] = useState<Donation[]>([])
  const [fetching, setFetching] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!loading && !user) navigate({ to: '/login' })
  }, [user, loading, navigate])

  useEffect(() => {
    if (!user) return
    authFetch('/api/donate')
      .then((r) => r.json())
      .then((data) => setDonations(data.donations || []))
      .catch(() => setError('Failed to load donations.'))
      .finally(() => setFetching(false))
  }, [user])

  if (loading || (!user && fetching)) return <LoadingScreen />
  if (!user) return null

  const totalDonated = donations.reduce((sum, d) => sum + d.amount, 0)
  const fmt = (n: number) =>
    new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)

  return (
    <div className="ganpati-bg min-h-screen">
      {/* Navbar */}
      <nav style={{ background: 'rgba(26,5,0,0.85)', borderBottom: '1px solid rgba(255,215,0,0.2)', backdropFilter: 'blur(12px)', padding: '12px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Link to="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span className="gold-text" style={{ fontSize: '1.6rem' }}>ॐ</span>
          <span className="gold-text font-bold">Ganpati Utsav</span>
        </Link>
        <div className="flex items-center gap-3">
          <Link to="/donate"><button className="btn-gold" style={{ padding: '8px 18px', fontSize: '0.85rem' }}>🙏 Donate</button></Link>
          <button onClick={() => logout()} className="btn-outline-gold" style={{ padding: '8px 16px', fontSize: '0.85rem' }}>Logout</button>
        </div>
      </nav>

      <div className="max-w-3xl mx-auto px-4 py-10">
        {/* Header */}
        <div className="mb-8">
          <div className="gold-text font-bold" style={{ fontSize: '1.8rem', marginBottom: '6px' }}>
            🙏 My Donation Dashboard
          </div>
          <p style={{ color: 'rgba(255,248,231,0.6)' }}>
            Welcome, <span className="saffron-text font-semibold">{user.user_metadata?.full_name || user.name || user.email}</span>
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
          <div className="stat-card">
            <div style={{ fontSize: '2rem', marginBottom: '6px' }}>💰</div>
            <div className="gold-text font-bold" style={{ fontSize: '1.4rem' }}>{fmt(totalDonated)}</div>
            <div style={{ color: 'rgba(255,248,231,0.55)', fontSize: '0.85rem', marginTop: '4px' }}>Total Donated</div>
          </div>
          <div className="stat-card">
            <div style={{ fontSize: '2rem', marginBottom: '6px' }}>🤲</div>
            <div className="gold-text font-bold" style={{ fontSize: '1.4rem' }}>{donations.length}</div>
            <div style={{ color: 'rgba(255,248,231,0.55)', fontSize: '0.85rem', marginTop: '4px' }}>Donations Made</div>
          </div>
          <div className="stat-card col-span-2 sm:col-span-1">
            <div style={{ fontSize: '2rem', marginBottom: '6px' }}>🌟</div>
            <div className="gold-text font-bold" style={{ fontSize: '1.1rem', wordBreak: 'break-all' }}>
              {user.email}
            </div>
            <div style={{ color: 'rgba(255,248,231,0.55)', fontSize: '0.85rem', marginTop: '4px' }}>Account</div>
          </div>
        </div>

        {/* Donation History */}
        <div className="card-ganesh-solid" style={{ padding: '24px' }}>
          <h2 className="gold-text font-bold mb-4" style={{ fontSize: '1.2rem' }}>
            Donation History
          </h2>

          {error && <div className="alert-error mb-4">{error}</div>}

          {fetching ? (
            <div className="text-center py-8" style={{ color: 'rgba(255,248,231,0.4)' }}>
              Loading donations…
            </div>
          ) : donations.length === 0 ? (
            <div className="text-center py-10">
              <div style={{ fontSize: '3rem', marginBottom: '12px' }}>🐘</div>
              <p style={{ color: 'rgba(255,248,231,0.5)', marginBottom: '20px' }}>
                You haven't made any donations yet.
              </p>
              <Link to="/donate">
                <button className="btn-gold">🙏 Make Your First Donation</button>
              </Link>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              {donations.map((d) => (
                <DonationItem key={d.id} donation={d} fmt={fmt} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function DonationItem({ donation: d, fmt }: { donation: Donation; fmt: (n: number) => string }) {
  const date = new Date(d.createdAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })

  return (
    <div className="donation-item flex items-start justify-between gap-4">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="gold-text font-bold" style={{ fontSize: '1.1rem' }}>{fmt(d.amount)}</span>
          <span style={{ background: 'rgba(255,215,0,0.15)', color: '#FFD700', fontSize: '0.7rem', padding: '2px 8px', borderRadius: '50px', border: '1px solid rgba(255,215,0,0.3)' }}>
            #{d.id.slice(0, 8).toUpperCase()}
          </span>
        </div>
        {d.message && (
          <p style={{ color: 'rgba(255,248,231,0.65)', fontSize: '0.9rem', fontStyle: 'italic', marginBottom: '4px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            "{d.message}"
          </p>
        )}
        <div style={{ color: 'rgba(255,248,231,0.4)', fontSize: '0.78rem' }}>
          🕐 {date}
        </div>
      </div>
      <div style={{ color: '#FFD700', fontSize: '1.5rem', flexShrink: 0 }}>🙏</div>
    </div>
  )
}

function LoadingScreen() {
  return (
    <div className="ganpati-bg min-h-screen flex items-center justify-center">
      <div className="gold-text text-center">
        <div className="om-glow" style={{ fontSize: '4rem', marginBottom: '16px' }}>ॐ</div>
        <p style={{ color: 'rgba(255,248,231,0.6)' }}>Loading…</p>
      </div>
    </div>
  )
}
