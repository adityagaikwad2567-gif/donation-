import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { useState, useEffect } from 'react'
import { useAuth } from '../components/AuthContext'
import { authFetch } from '../lib/api'

export const Route = createFileRoute('/donate')({
  component: DonatePage,
})

const PRESET_AMOUNTS = [101, 251, 501, 1001, 2101, 5001, 11000, 21000]

function DonatePage() {
  const { user, loading } = useAuth()
  const navigate = useNavigate()
  const [amount, setAmount] = useState<number | ''>('')
  const [selectedPreset, setSelectedPreset] = useState<number | null>(null)
  const [message, setMessage] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [receipt, setReceipt] = useState<any>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    if (!loading && !user) navigate({ to: '/login' })
  }, [user, loading, navigate])

  if (loading) return <LoadingScreen />
  if (!user) return null

  const displayAmount = selectedPreset ?? amount

  function selectPreset(val: number) {
    setSelectedPreset(val)
    setAmount(val)
  }

  function handleCustomAmount(val: string) {
    setSelectedPreset(null)
    const n = parseInt(val)
    setAmount(isNaN(n) ? '' : n)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!amount || Number(amount) <= 0) {
      setError('Please enter a valid donation amount.')
      return
    }
    setError('')
    setSubmitting(true)

    try {
      const res = await authFetch('/api/donate', {
        method: 'POST',
        body: JSON.stringify({
          amount: Number(amount),
          message,
          donorName: user.user_metadata?.full_name || user.name || user.email,
          phone: user.user_metadata?.phone || '',
        }),
      })

      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.error || 'Failed to process donation')
      }

      const data = await res.json()
      setReceipt(data.donation)
    } catch (err: any) {
      setError(err.message || 'Something went wrong. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  if (receipt) {
    return <ReceiptView receipt={receipt} onDonateAgain={() => { setReceipt(null); setAmount(''); setMessage(''); setSelectedPreset(null) }} />
  }

  return (
    <div className="ganpati-bg min-h-screen">
      {/* Navbar */}
      <nav style={{ background: 'rgba(26,5,0,0.85)', borderBottom: '1px solid rgba(255,215,0,0.2)', backdropFilter: 'blur(12px)', padding: '12px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Link to="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span className="gold-text" style={{ fontSize: '1.6rem' }}>ॐ</span>
          <span className="gold-text font-bold">Ganpati Utsav</span>
        </Link>
        <div className="flex gap-3">
          <Link to="/dashboard"><button className="btn-outline-gold" style={{ padding: '8px 16px', fontSize: '0.85rem' }}>My Donations</button></Link>
          <Link to="/"><button className="btn-outline-gold" style={{ padding: '8px 16px', fontSize: '0.85rem' }}>Home</button></Link>
        </div>
      </nav>

      <div className="max-w-xl mx-auto px-4 py-10">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="gold-text" style={{ fontSize: '3rem', marginBottom: '8px' }}>🙏</div>
          <h1 className="gold-text font-bold" style={{ fontSize: '2rem', marginBottom: '8px' }}>Make a Donation</h1>
          <p style={{ color: 'rgba(255,248,231,0.65)' }}>
            Welcome, <span className="saffron-text font-semibold">{user.user_metadata?.full_name || user.name || user.email}</span>
          </p>
        </div>

        <div className="mandala-border" style={{ padding: '36px 28px' }}>
          {error && <div className="alert-error mb-5">{error}</div>}

          <form onSubmit={handleSubmit} className="flex flex-col gap-6">
            {/* Preset amounts */}
            <div>
              <label style={{ color: '#FFD700', fontSize: '0.9rem', fontWeight: 700, display: 'block', marginBottom: '12px' }}>
                Select Amount (₹)
              </label>
              <div className="flex flex-wrap gap-2 mb-4">
                {PRESET_AMOUNTS.map((a) => (
                  <button
                    key={a}
                    type="button"
                    onClick={() => selectPreset(a)}
                    className={`amount-chip${selectedPreset === a ? ' selected' : ''}`}
                    style={{ fontSize: '0.9rem' }}
                  >
                    ₹{a.toLocaleString('en-IN')}
                  </button>
                ))}
              </div>
              <div className="lotus-divider" style={{ margin: '12px 0' }}>
                <span style={{ color: 'rgba(255,215,0,0.5)', fontSize: '0.8rem' }}>or enter custom amount</span>
              </div>
              <div style={{ position: 'relative' }}>
                <span style={{ position: 'absolute', left: '14px', top: '50%', transform: 'translateY(-50%)', color: '#FFD700', fontWeight: 700, fontSize: '1.1rem' }}>₹</span>
                <input
                  type="number"
                  className="input-ganesh"
                  style={{ paddingLeft: '36px' }}
                  placeholder="Enter amount"
                  value={selectedPreset === null ? amount : ''}
                  onChange={(e) => handleCustomAmount(e.target.value)}
                  min={1}
                />
              </div>
              {displayAmount ? (
                <p style={{ color: '#FFD700', fontSize: '0.85rem', marginTop: '8px', textAlign: 'center' }}>
                  Donating: ₹{Number(displayAmount).toLocaleString('en-IN')}
                </p>
              ) : null}
            </div>

            {/* Message */}
            <div>
              <label style={{ color: '#FFD700', fontSize: '0.9rem', fontWeight: 700, display: 'block', marginBottom: '6px' }}>
                Dedication / Message <span style={{ color: 'rgba(255,248,231,0.4)', fontWeight: 400 }}>(optional)</span>
              </label>
              <textarea
                className="input-ganesh"
                style={{ resize: 'vertical', minHeight: '80px' }}
                placeholder="e.g. In memory of our ancestors, for the prosperity of our family..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                maxLength={300}
              />
              <div style={{ color: 'rgba(255,248,231,0.35)', fontSize: '0.75rem', textAlign: 'right', marginTop: '4px' }}>
                {message.length}/300
              </div>
            </div>

            {/* Receipt info */}
            <div className="card-ganesh" style={{ padding: '14px 16px', fontSize: '0.85rem' }}>
              <div style={{ color: '#FFD700', fontWeight: 600, marginBottom: '6px' }}>📨 Receipt Delivery</div>
              <div style={{ color: 'rgba(255,248,231,0.65)' }}>
                Email: <span style={{ color: '#FFF8E7' }}>{user.email}</span>
              </div>
              {user.user_metadata?.phone && (
                <div style={{ color: 'rgba(255,248,231,0.65)', marginTop: '4px' }}>
                  SMS: <span style={{ color: '#FFF8E7' }}>{user.user_metadata.phone}</span>
                </div>
              )}
            </div>

            <button
              type="submit"
              className="btn-gold w-full"
              style={{ padding: '16px', fontSize: '1.1rem' }}
              disabled={submitting || !displayAmount}
            >
              {submitting ? '⏳ Processing…' : '🙏 Donate Now — Jai Ganesh!'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

function ReceiptView({ receipt, onDonateAgain }: { receipt: any; onDonateAgain: () => void }) {
  const fmt = (n: number) =>
    new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)
  const date = new Date(receipt.createdAt).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })

  return (
    <div className="ganpati-bg min-h-screen flex flex-col items-center justify-center px-4 py-10">
      <div className="mandala-border text-center" style={{ maxWidth: '480px', width: '100%', padding: '40px 32px' }}>
        <div style={{ fontSize: '4rem', marginBottom: '12px' }}>🎉</div>
        <h1 className="gold-text font-bold" style={{ fontSize: '1.8rem', marginBottom: '6px' }}>
          Ganpati Bappa Morya!
        </h1>
        <p style={{ color: '#FF6B2B', fontSize: '1rem', marginBottom: '24px' }}>
          Your offering has been received
        </p>

        <div className="lotus-divider mb-6">
          <span style={{ color: '#FFD700' }}>✿</span>
        </div>

        {/* Receipt details */}
        <div className="card-ganesh" style={{ padding: '20px', marginBottom: '20px', textAlign: 'left' }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
            {[
              { label: 'Receipt ID', value: `#${receipt.id.slice(0, 8).toUpperCase()}` },
              { label: 'Amount', value: fmt(receipt.amount) },
              { label: 'Donor', value: receipt.donorName },
              { label: 'Date', value: date },
            ].map(({ label, value }) => (
              <div key={label}>
                <div style={{ color: 'rgba(255,215,0,0.7)', fontSize: '0.75rem', marginBottom: '2px' }}>{label}</div>
                <div style={{ color: '#FFF8E7', fontWeight: 600 }}>{value}</div>
              </div>
            ))}
          </div>
          {receipt.message && (
            <div style={{ marginTop: '14px', borderTop: '1px solid rgba(255,215,0,0.15)', paddingTop: '14px' }}>
              <div style={{ color: 'rgba(255,215,0,0.7)', fontSize: '0.75rem', marginBottom: '4px' }}>Dedication</div>
              <div style={{ color: '#FFF8E7', fontStyle: 'italic' }}>{receipt.message}</div>
            </div>
          )}
        </div>

        <div className="alert-success mb-6" style={{ textAlign: 'center' }}>
          📧 A receipt has been sent to your email
          {receipt.phone ? ' and SMS' : ''}.
        </div>

        <div style={{ color: 'rgba(255,248,231,0.6)', fontSize: '0.9rem', marginBottom: '24px', lineHeight: 1.6 }}>
          🙏 May Lord Ganesha bless you with prosperity, happiness, and the removal of all obstacles.
        </div>

        <div className="flex gap-3 justify-center flex-wrap">
          <button onClick={onDonateAgain} className="btn-gold">
            Donate Again
          </button>
          <Link to="/dashboard">
            <button className="btn-outline-gold">View History</button>
          </Link>
          <Link to="/">
            <button className="btn-saffron">Home</button>
          </Link>
        </div>
      </div>
    </div>
  )
}

function LoadingScreen() {
  return (
    <div className="ganpati-bg min-h-screen flex items-center justify-center">
      <div className="gold-text text-center">
        <div className="om-glow" style={{ fontSize: '4rem', marginBottom: '16px' }}>ॐ</div>
        <p style={{ color: 'rgba(255,248,231,0.6)' }}>Loading…</p>
      </div>
    </div>
  )
}
