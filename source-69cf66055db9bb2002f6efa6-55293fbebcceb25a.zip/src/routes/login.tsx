import { createFileRoute, Link, useNavigate } from '@tanstack/react-router'
import { useState } from 'react'
import { useAuth } from '../components/AuthContext'
import { GaneshaIcon } from '../components/GaneshaIcon'

export const Route = createFileRoute('/login')({
  component: LoginPage,
})

function LoginPage() {
  const { login, user } = useAuth()
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  if (user) {
    navigate({ to: '/' })
    return null
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      await login(email, password)
      navigate({ to: '/donate' })
    } catch (err: any) {
      const status = err?.status
      if (status === 401) setError('Invalid email or password.')
      else if (err?.message) setError(err.message)
      else setError('Login failed. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div
      className="ganpati-bg min-h-screen flex flex-col items-center justify-center"
      style={{ padding: '24px 16px' }}
    >
      {/* Top nav bar */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, padding: '16px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Link to="/" style={{ textDecoration: 'none', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <span className="gold-text" style={{ fontSize: '1.6rem' }}>ॐ</span>
          <span className="gold-text font-bold">Ganpati Utsav</span>
        </Link>
        <Link to="/register"><button className="btn-outline-gold" style={{ padding: '8px 20px', fontSize: '0.9rem' }}>Register</button></Link>
      </div>

      {/* Card */}
      <div className="mandala-border" style={{ width: '100%', maxWidth: '420px', padding: '40px 32px' }}>
        {/* Header */}
        <div className="text-center mb-8">
          <GaneshaIcon size={80} className="mx-auto mb-4" />
          <div className="om-glow gold-text" style={{ fontSize: '2rem', marginBottom: '8px' }}>ॐ</div>
          <h1 className="gold-text font-bold" style={{ fontSize: '1.8rem', marginBottom: '6px' }}>Welcome Back</h1>
          <p style={{ color: 'rgba(255,248,231,0.6)', fontSize: '0.95rem' }}>
            Sign in to continue your devotion
          </p>
        </div>

        <div className="lotus-divider mb-6">
          <span style={{ color: '#FFD700' }}>✿</span>
        </div>

        {error && <div className="alert-error mb-4">{error}</div>}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div>
            <label style={{ color: '#FFD700', fontSize: '0.85rem', fontWeight: 600, display: 'block', marginBottom: '6px' }}>
              Email Address
            </label>
            <input
              type="email"
              className="input-ganesh"
              placeholder="devotee@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              autoComplete="email"
            />
          </div>
          <div>
            <label style={{ color: '#FFD700', fontSize: '0.85rem', fontWeight: 600, display: 'block', marginBottom: '6px' }}>
              Password
            </label>
            <input
              type="password"
              className="input-ganesh"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              autoComplete="current-password"
              minLength={8}
            />
          </div>

          <button
            type="submit"
            className="btn-gold w-full mt-2"
            style={{ padding: '14px', fontSize: '1rem' }}
            disabled={loading}
          >
            {loading ? 'Signing in…' : '🙏 Sign In'}
          </button>
        </form>

        <div className="lotus-divider mt-6 mb-4">
          <span style={{ color: 'rgba(255,215,0,0.5)', fontSize: '0.85rem' }}>New devotee?</span>
        </div>

        <Link to="/register" style={{ textDecoration: 'none', display: 'block', textAlign: 'center' }}>
          <button className="btn-saffron w-full" style={{ padding: '12px', fontSize: '0.95rem' }}>
            Create Account
          </button>
        </Link>
      </div>

      <p style={{ color: 'rgba(255,248,231,0.3)', fontSize: '0.8rem', marginTop: '24px' }}>
        Ganpati Bappa Morya 🐘
      </p>
    </div>
  )
}
